function putLfd(Lfdobjcell, bifdParobj)
%  Replace the Lfd parameters

bifdParobj.Lfds = Lfdobjcell{1};
bifdParobj.Lfdt = Lfdobjcell{2};