function basisobj = getbasis(fdParobj)
fdobj = getfd(fdParobj);
basisobj = getbasis(fdobj);